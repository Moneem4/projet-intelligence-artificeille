/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cancerdetection;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.RandomAccessFile;
import java.io.UnsupportedEncodingException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import weka.classifiers.Evaluation;
import weka.classifiers.bayes.NaiveBayes;
import weka.classifiers.trees.J48;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.CSVLoader;

/**
 *
 * @author ROG G752
 */
public class Gourmandise {

    public static void main(String[] args) throws UnsupportedEncodingException, IOException {
        String path1 = "E:\\newA.arff";
        String path2 = "E:\\testA.arff";
        try {

           Instances dataset=new Instances(new BufferedReader(new FileReader(path1)));
            Instances test=new Instances(new BufferedReader(new FileReader(path2)));
            System.out.println(dataset.toSummaryString());
            System.out.println(dataset.numAttributes());

            test.setClassIndex(3);
            dataset.setClassIndex(3);
            System.out.println("+++++++++++++++++++++++++++++++"+dataset.numAttributes());
            
          
            
            NaiveBayes nb = new NaiveBayes();
            Evaluation eval = new Evaluation(dataset);

           

           
            nb.buildClassifier(dataset);
            Instance newInst = test.instance(0);

            double predNB = nb.classifyInstance(newInst);

            String predString = test.classAttribute().value((int) predNB);
            System.out.println("PREEEE/ " + predString);

            eval.evaluateModel(nb, test);

            try {
                RandomAccessFile raf = new RandomAccessFile(path2, "rw");
                long length = raf.length();

                //supposing that last line is of 8 
                raf.close();

            } catch (Exception ex) {
                ex.printStackTrace();
            }

        } catch (FileNotFoundException ex) {
            Logger.getLogger(WekaEvaluation.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(WekaEvaluation.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex) {
            Logger.getLogger(WekaEvaluation.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}

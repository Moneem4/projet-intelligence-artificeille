/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cancerdetection;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.LayoutManager;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author ROG G752
 */
public class SoloItem extends JPanel{
    private JLabel label;
    private JTextField input;

    public SoloItem(String labelString) {
        super(new FlowLayout());
        this.label = new JLabel(labelString);
        this.input = new JTextField();
        this.label.setSize(new Dimension(60, 25));
        this.input.setSize(new Dimension(60, 25));
        this.input.setPreferredSize(new Dimension(60, 25));
        this.add(label);
        this.add(input);
        this.setSize(150, 50);
        
    }

    public JLabel getLabel() {
        return label;
    }

    public String getInput() {
        return input.getText();
    }

    public void setLabel(JLabel label) {
        this.label = label;
    }

    public void setInput(JTextField input) {
        this.input = input;
    }
    
    
}

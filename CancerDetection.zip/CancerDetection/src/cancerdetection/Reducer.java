/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cancerdetection;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ROG G752
 */
public class Reducer {
    
    public static List<Celll> test;
    public static List<Celll> train;
    public static void main(String[] args) {
       
        
//        try {
//            BufferedWriter bwTest = new BufferedWriter(new FileWriter(new File("E:\\tall.csv"), true));
//            BufferedReader late = new BufferedReader(new FileReader(new File("E:\\lasttest.csv")));
//            BufferedReader testt = new BufferedReader(new FileReader(new File("E:\\test.csv")));
//            String line=testt.readLine();
//            String line2=late.readLine();
//            while((line=testt.readLine())!=null){
//                line2=late.readLine();
//               
//                String[] tabb = line.split(",");
//                
//                String[] tabb2 = line2.split(",");
//                tabb2[2]=tabb[2];
//                String hhj =tabb2[0]+"|"+tabb2[1]+"|"+tabb2[2]+","+tabb2[3]+"\n";
//                bwTest.write(hhj);
//            }
//          
//         bwTest.close();
//           
//            
//        } catch (FileNotFoundException ex) {
//            Logger.getLogger(Reducer.class.getName()).log(Level.SEVERE, null, ex);
//        } catch (IOException ex) {
//            Logger.getLogger(Reducer.class.getName()).log(Level.SEVERE, null, ex);
//        }
        
        BufferedWriter bwTest = null;
        ArrayList<Celll> arrr=new ArrayList<>();
        try {
            red();
            bwTest = new BufferedWriter(new FileWriter(new File("E:\\lasttest.csv"), true));
            for (int i = 0; i < test.size(); i++) {
                
                int j=0;
                arrr.add(train.get(j));
                for  (j=0; j<train.size();j++) {
                if(!test.get(i).equals(train.get(j))){
                    
                }
                
                    
                }
                System.out.println(j<train.size());
                if(j<train.size()){
                    
                   arrr.add(train.get(j));
                }
                String ll =test.get(i).toString()+test.get(j).getQuantityP(arrr)+"\n";
                    
                    bwTest.write(ll);
            }
            
            
            
            
            
            
            
            
            
            
            
        } catch (IOException ex) {
            Logger.getLogger(Reducer.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                bwTest.close();
            } catch (IOException ex) {
                Logger.getLogger(Reducer.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
    }
    
    public static void red(){
      
           
        BufferedReader brtrain = null;
        test = new ArrayList<>();
        train = new ArrayList<>();
        try {
            BufferedWriter bwTest = new BufferedWriter(new FileWriter(new File("E:\\train_Numerical_data.csv"), true));
            BufferedReader brtest = new BufferedReader(new FileReader(new File("E:\\test.csv")));
            brtrain = new BufferedReader(new FileReader(new File("E:\\train_Numerical_data.csv")));
            String line=brtest.readLine();
            while((line=brtest.readLine())!=null){
                test.add(extract(line));  
            }
          line=brtrain.readLine();
         
            while((line=brtrain.readLine())!=null){
                
                train.add(extract2(line));  
            }
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Reducer.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Reducer.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                brtrain.close();
            } catch (IOException ex) {
                Logger.getLogger(Reducer.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
       
    }
    
    public static Celll extract(String ch){
       
        String[] tab= ch.split("\\|");
        
        return new Celll(tab[0],tab[1],tab[2].substring(0, tab[2].length()-1));
    
}
    
  public static Celll extract2(String ch){
       
        String[] tab= ch.split(",");
     
        return new Celll(tab[0],tab[1],tab[13],Float.parseFloat(tab[3]));
    
}
    
}

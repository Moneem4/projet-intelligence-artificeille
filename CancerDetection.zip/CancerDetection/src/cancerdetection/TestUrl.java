/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cancerdetection;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ROG G752
 */
public class TestUrl {
 
    URL url;
    BufferedReader reader = null;
    

    public TestUrl() {
        try {
            //this.url = new URL("https://www.facebook.com/");
            this.url = new URL("https://csgofast.com/#game/double");
            URLConnection uc=url.openConnection();
            //HttpURLConnection uc = (HttpURLConnection) url.openConnection(); 
 uc.addRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:25.0) Gecko/20100101 Firefox/25.0");
 //System.setProperty("http.agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:25.0) Gecko/20100101 Firefox/25.0");
            
        uc.addRequestProperty("User-Agent","Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0)");
           BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));
        String line = null;
        while ((line = reader.readLine()) != null) {
            System.out.println(line);
            
        }
        
        
        
        
        
        
        } catch (MalformedURLException ex) {
            Logger.getLogger(TestUrl.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(TestUrl.class.getName()).log(Level.SEVERE, null, ex);
        }
        finally {
        if (reader != null)
                try {
                    reader.close();
        } catch (IOException ex) {
            Logger.getLogger(TestUrl.class.getName()).log(Level.SEVERE, null, ex);
        }}
       
    }


    public static void main(String[] args) {
        TestUrl t=new TestUrl();
    }
}

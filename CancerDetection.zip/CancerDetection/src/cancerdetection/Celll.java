/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cancerdetection;

import java.util.ArrayList;
import java.util.Date;
import java.util.Objects;

/**
 *
 * @author ROG G752
 */
class Celll {
    String store;
    String item;
    String date;
    float quant;

    public Celll(String store, String item, String date) {
        this.store = store;
        this.item = item;
        this.date = date;
    }
    public Celll(String store, String item, String date,float quant) {
        this.store = store;
        this.item = item;
        this.date = date;
        this.quant = quant;
    }
      public Celll() {
        this.store = "";
        this.item = "";
        this.date = null;
    }

    public void setStore(String store) {
        this.store = store;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public void setDate(String date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return store+","+item+","+date+",";
    }

    public String getStore() {
        return store;
    }

    public String getItem() {
        return item;
    }

    public String getDate() {
        return date;
    }
public float getQuant() {
        return quant;
    }
   
    @Override
    public boolean equals(Object obj) {
      Celll cl2=(Celll)obj;
      
        if ((cl2.getItem().equals(this.item))&&(cl2.getStore().equals((this.store)))) {
            return true;
        }else{
            return false;
        }
    }
    
    public float getQuantityP(ArrayList<Celll> al){
        float moy=0;
        for (int i = 0; i < al.size(); i++) {
            moy+=al.get(i).getQuant();
        }
        
        
        
        return moy/al.size();
    }
}

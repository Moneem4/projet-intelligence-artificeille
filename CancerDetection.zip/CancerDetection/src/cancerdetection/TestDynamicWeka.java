/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cancerdetection;


import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.HeadlessException;
import java.awt.PopupMenu;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import weka.core.Instances;

/**
 *
 * @author ROG G752
 */
public class TestDynamicWeka extends JFrame{

    private JPanel container;
    private JButton bb;
    private JButton pathchooser;
    private String path;
    public TestDynamicWeka(String pathed)  {
        path=pathed;
        container=new JPanel(new FlowLayout(FlowLayout.CENTER));
        
        bb=new JButton("Test");
       
        
                
        
        
        try{
            BufferedReader reader=new BufferedReader(new FileReader(path));
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("src\\cancerdetection\\auxx.arff"), "utf-8"));
            String line;
            
            while((line=reader.readLine())!=null){
                if(!line.equals("@data")){
                writer.write(line);
                writer.write('\n');
                System.out.println(line);}
                else{writer.write("@data");writer.write('\n');break;}
            }
            writer.close();
            reader=new BufferedReader(new FileReader(path));
            Instances dataset=new Instances(reader);
            dataset.setClassIndex(dataset.numAttributes()-1);
            JPanel jpa=new JPanel();
            for(int i=0;i<dataset.numAttributes()-1;i++){
                System.out.println(dataset.attribute(i).name());
                container.add(new SoloItem(dataset.attribute(i).name()));
                
                jpa.setPreferredSize( new Dimension( 640, 50 ) );
                container.add(jpa);
            }
            
            
            container.remove(jpa);
            container.add(bb);
            
            bb.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
               StringBuilder output = new StringBuilder();
                    for(int i=0;i<dataset.numAttributes()-1;i++){
                         SoloItem si=(SoloItem) container.getComponent(i);
                         //System.out.println(si.getInput());
                         output.append(si.getInput()+',');
                     }
                     output.append('?');
                    try {
                        BufferedWriter foutput = new BufferedWriter(new FileWriter("src\\cancerdetection\\auxx.arff", true));
                        foutput.append(output.toString());
                        foutput.close();
                        new WekaEvaluation(output.toString(),path, "src\\cancerdetection\\auxx.arff");
                    } catch (IOException ex) {
                        Logger.getLogger(TestDynamicWeka.class.getName()).log(Level.SEVERE, null, ex);
                    }
                     System.out.println(output.toString());
                }
            });
            
            
            
            
            
        }catch(Exception e){
            System.out.println(e);
        }
    this.add(container);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            revalidate();
            repaint();
            SwingUtilities.updateComponentTreeUI(this);

            setSize(new Dimension(300, 900));
            this.setVisible(true);
            
    
    
    
    }
    
    public static void main(String[] args) {
        new TestDynamicWeka("");
    }
    
    
    
}
